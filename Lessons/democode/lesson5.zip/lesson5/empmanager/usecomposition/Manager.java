package lesson5.empmanager.usecomposition;

import java.time.LocalDate;
import java.util.Date;


/** Implementation of Manager using Compostion instead of Inheritance.
 *  Now we can't use Manager in context of polymorphism, but it can
 *  support a different equals implementation.
 *  
 */
public class Manager {
	private Employee emp;
	private double bonus;

	
	@Override
	public boolean equals(Object ob) {
		if(ob == null) return false;
		if(this.getClass() != ob.getClass())
			return false;
		Manager m = (Manager) ob;
		return this.bonus == m.bonus && this.emp.equals(m.emp);
	}
	
	public static void main(String[] args) {
		Employee e = new Employee("mike", 50000, 2017, 9, 9);
		Manager m = new Manager("mike", 50000, 2017, 9, 9, 0.25);
		System.out.println(e.equals(m));
		System.out.println(m.equals(e));
	}
	
	public Manager(String name, double salary, int year, int month, int day) {
		emp = new Employee(name,salary, year, month, day);
		bonus = 0;
	}	
	public Manager(String name, double salary, int year, int month, int day, double bonus) {
		emp = new Employee(name,salary, year, month, day);
		this.bonus = bonus;
	}
	public double getSalary() {
		double baseSalary = emp.getSalary();
		return baseSalary + bonus;
	}
	public String getName() {
		return emp.getName();
	}
	public LocalDate getHireDay() {
		return emp.getHireDay();
	}
	public void setBonus(double b) {
		bonus = b;
	}	
	
	
}
