package lesson5.comparable;


public class Customer implements Comparable<Customer> {
	private String firstName;
	private String lastName;
	private String socSecurityNum;
	public Customer(String fName, String lName, String ssn) {
		firstName = fName;
		lastName = lName;
		socSecurityNum = ssn;
	}

	public String toString() {
		return "[" + firstName + ", " + lastName + ", " + "ssn: " + socSecurityNum + "]";
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getSocSecurityNum() {
		return socSecurityNum;
	}

	public void setSocSecurityNum(String socSecurityNum) {
		this.socSecurityNum = socSecurityNum;
	}
	
	@Override
	public int compareTo(Customer c) {
		if(c == null)
			return 1;
		if(!this.firstName.equals(c.firstName)) {
			return this.firstName.compareTo(c.firstName);
		}
		if(!this.lastName.equals(c.lastName))
			return this.lastName.compareTo(c.lastName);
		
		return this.socSecurityNum.compareTo(c.socSecurityNum);
	}

}
