package lesson5.comparable;

public class Main {

	public static void main(String[] args) {
		Customer c = new Customer("Raja", "Kadurka", "123-890-7865");
		Customer d = null;
		System.out.println(c.compareTo(d));
		Customer a = new Customer("Carl", "Mapada", "123-870-7865");
		System.out.println(c.compareTo(a));
		Customer b = new Customer("Carl", "Mapada", "124-870-7865");
		System.out.println(a.compareTo(b));
	}
}
