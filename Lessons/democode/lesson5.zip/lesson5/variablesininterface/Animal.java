package lesson5.variablesininterface;

public interface Animal {
	//implicitly final
	int x = 1;
}
