package lesson5.variablesininterface;

public abstract class Abstr {
	abstract void method();
}
