package lesson4.dates;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class AboutDates {
	
	//Formatting LocalDates as strings and reading date strings as LocalDates
	public static final String DATE_PATTERN = "yyyy/MM/dd/"; 
	public static LocalDate localDateForString(String date) {
		return LocalDate.parse(date, DateTimeFormatter.ofPattern(DATE_PATTERN));
	}
		
	public static String localDateAsString(LocalDate date) {  	
		return 	date.format(DateTimeFormatter.ofPattern(DATE_PATTERN));
	}

	public static void main(String[] args) {
		System.out.println("Today's date: " + LocalDate.now());
		System.out.println("Specified date: " + LocalDate.of(2000, 1, 1));
		System.out.println(localDateForString("06/15/1988"));
		LocalDate d = LocalDate.of(2000, 1, 1);  //01/01/2000
		System.out.println(localDateAsString(d));
	}

}
