package lesson4.stringbuilder;

public class Test {

	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder();
		sb.append("Welcome ");
		sb.append("To ");
		sb.append("CS390");
		System.out.println(sb.toString());
	}
}
