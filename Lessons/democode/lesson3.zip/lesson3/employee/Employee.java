package lesson3.employee;

import java.time.LocalDate;

public class Employee {
	//fields
	private String name;
	private String nickName;
	private double salary;
	private LocalDate hireDay;

	// constructor
	public Employee(String aName, String aNickName, double aSalary, int aYear,
			int aMonth, int aDay) {
		this.name = aName;
		this.nickName = aNickName;
		this.salary = aSalary;
		this.hireDay = LocalDate.of(aYear, aMonth, aDay);
	}

	public Employee(String aName, String aNickName) {
		this(aName, aNickName, 0, 2000, 4, 1);
	}
	public Employee() {
		this("default", "default", 0, 2000, 4, 1);
	}
	// instance methods
	public String getName() {
		return name;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String aNickName) {
		nickName = aNickName;
	}
	public double getSalary() {
		return salary;
	}

	public LocalDate getHireDay() {
		return hireDay;
	}
	public void raiseSalary(double byPercent) { //this
		double raise = salary * byPercent / 100;
		//salary = this.getSalary() + raise;
		salary = this.salary + raise;
	}
}
