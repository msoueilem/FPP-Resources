package lesson3.employee;

import java.time.LocalDate;

public class EmployeeTest {
	public static void main(String[] args) {
		LocalDate d = LocalDate.of(2021, 2, 10);
		Employee e1 = new Employee("Carl", "Jones", 75000, 1987, 12, 15);
		Employee e2 = new Employee("Mike", "Jones", 75000, 1987, 12, 15);
		e1.raiseSalary(10);
		e2.raiseSalary(20);
		System.out.println(e1.getSalary());
	}	
}


