package lesson3.labelwithenums;

public enum Alignment {
	LEFT, CENTER, RIGHT;
}
