package lesson3.reference.example;

import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 * Represents profile information for an Employee.
 * @author Mei Li
 */
public class Employee {
	private String firstName;
	private String lastName;
	private double salary;
	private Address home;
	private Address work;
	public Employee(String fName, String lName) {
		firstName = fName;
		lastName = lName;
	}
	//default constructor
	public Employee() {
		this("_Placeholder","Employee");
	}

	/** Provides a string representation of this Employee */
	public String toString() {
		return "[" + firstName + " " + lastName + "]";
	}
	public double getSalary() {
		return salary;
	}

	public double raiseSalary(int increase) {
		return salary += increase;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}
	public Address getHome() {
		return home;
	}
	public void setHome(Address home) {
		this.home = home;
	}
	public Address getWork() {
		return work;
	}
	public void setWork(Address work) {
		this.work = work;
	}
	public String getFirstName() {
		return firstName;
	}
	public String getLastName() {
		return lastName;
	}

	public static void main(String[] args) {

		Employee e = new Employee("Anne", "Brown");
		e.setSalary(5000);
		e.raiseSalary(3000);
		System.out.println(e.getSalary());


		GregorianCalendar cal = new GregorianCalendar(2017, 4, 28);
		int month = cal.get(Calendar.MONTH);
		int weekday = cal.get(Calendar.DAY_OF_WEEK);
		int daynum = cal.get(Calendar.DATE);
		System.out.println(daynum);
		System.out.println(weekday);
		cal.set(Calendar.YEAR, 2001);
		cal.set(Calendar.DATE, 23);


	}
}
