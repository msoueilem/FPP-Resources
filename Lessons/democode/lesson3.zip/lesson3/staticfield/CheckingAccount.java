package lesson3.staticfield;

public class CheckingAccount {

	private static double interestRate = 0.05;
	
	public CheckingAccount() {
		
	}
	public void setInterestRate(double b) {
		interestRate = b;
	}
	public static void main(String[] args) {
		CheckingAccount a1 = new CheckingAccount();
		CheckingAccount a2 = new CheckingAccount();
		System.out.println(a1.interestRate);
		System.out.println(a2.interestRate);
		a1.setInterestRate(0.1);
		System.out.println(a1.interestRate);
		System.out.println(a2.interestRate);	
	}
}

