package lesson3.blankfinal;


public class BlankFinal {
	private final int blankFinal;
			
	public BlankFinal() {
		blankFinal = 3;
	}
	
	public static void main(String[] args) {
	}

}
