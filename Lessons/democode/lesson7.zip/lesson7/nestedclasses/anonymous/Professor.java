package lesson7.nestedclasses.anonymous;

public abstract class Professor {

	abstract double getSalary();

	public static void main(String[] args) {
//		new Professor();
		Professor p = new Professor() {

			@Override
			double getSalary() {
				return 4000;
			}
		};
		System.out.println(p.getSalary());
		Professor p2 = new Professor() {

			@Override
			double getSalary() {
				return 5000;
			}
		};
		System.out.println(p2.getClass());
	}
}
