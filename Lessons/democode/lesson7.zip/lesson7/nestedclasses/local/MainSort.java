package lesson7.nestedclasses.local;
import java.util.*;

public class MainSort {

	private String a;
	
	public static void main(String[] a) {
		
		Employee e1 = new Employee("Bob", 200000);
		Employee e2 = new Employee("Anne", 150000);
		
//		MyComparator m = new MyComparator();
//		System.out.println(m.compare(e1, e2));
		
				
		Employee[] emps = {e1,
				e2,
				new Employee("Steve", 155000)};
//		
//		Arrays.sort(emps, m);
//		System.out.println(Arrays.toString(emps));
		
		int b = 9;
		class NameComparator implements Comparator<Employee>{
			@Override
			public int compare(Employee o1, Employee o2) {
//				b = 10;
				return o1.getName().compareTo(o2.getName());
			}
		}	
		Arrays.sort(emps, new NameComparator());
		System.out.println(Arrays.toString(emps));
		
	
		
		
		
		
		
		
		
		
		
		
		
//		class SalaryComparator implements Comparator<Employee>{
//			@Override
////			5.6 - 5.3 = 0.3
//			public int compare(Employee o1, Employee o2) {
//				// TODO Auto-generated method stub
//				Double d1 = o1.getSalary();
//				Double d2 = o2.getSalary();
//				return d1.compareTo(d2);
//			}
//		}		
//		Arrays.sort(emps, new SalaryComparator());
//		System.out.println(Arrays.toString(emps));
	}
}
