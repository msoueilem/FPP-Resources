package lesson7.nestedclasses.local;

import java.util.Comparator;

public class MyComparator implements Comparator<Employee> {

	@Override
	public int compare(Employee o1, Employee o2) {
		int a = o1.getName().compareTo(o2.getName());
		if(a != 0)
			return a;
		return new Double(o1.getSalary()).compareTo(new Double(o2.getSalary()));
	}

}
