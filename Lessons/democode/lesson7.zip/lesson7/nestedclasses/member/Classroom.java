package lesson7.nestedclasses.member;

//enclosing/surrounding
public class Classroom {

	private String roomNo;

	// member inner class
	class Projector {
		private double price;
		Projector(double price) {
			this.price = price;
		}
		public String locate() {
//			aMethod();
			return roomNo;
		}
	}

	public void aMethod() {
//		System.out.println(price);
		Projector p = new Projector(800.8);
		System.out.println(p.price);
	}


	public static void main(String[] args) {
		new Classroom().aMethod();
	}
}