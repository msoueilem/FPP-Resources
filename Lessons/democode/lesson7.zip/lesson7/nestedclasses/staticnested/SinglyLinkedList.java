package lesson7.nestedclasses.staticnested;


public class SinglyLinkedList {
	//static nested class
	static class Node {
		String data;
		Node next;
		
		@Override
		public String toString() {
			return data + " ";
		}
	}
	Node header = null; //contains no data, cannot be removed
	
	public SinglyLinkedList() {
		//header should never be null
		header = new Node();
	}
	void printNodes() {
		Node next = header.next;
		while(next != null) {
			System.out.print(next);
			next = next.next;
		}
		System.out.println();
	}
	void addNode(String s) {
		Node newNode = new Node();
		newNode.data = s;
		
		//link from newNode to current header.node
		newNode.next = header.next;
		
		//link from header to newNode
		header.next = newNode;		
	}
	void removeNode(String s) {
		if(s == null) return;
		Node next = header.next;
		Node previous = header;
		while(next != null) {
			if(s.equals(next.data)) {
				previous.next = next.next;
				return;
			}
			previous = next;
			next = next.next;		
		}
	}
}


