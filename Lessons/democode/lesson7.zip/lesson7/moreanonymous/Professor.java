package lesson7.moreanonymous;

public abstract class Professor {

	abstract double getSalary();

	public static void main(String[] args) {
		Professor p = new Professor() {

			@Override
			double getSalary() {
				// TODO Auto-generated method stub
				return 4000;
			}
		};
		Professor p2 = new Professor() {

			@Override
			double getSalary() {
				// TODO Auto-generated method stub
				return 4000;
			}
		};
		System.out.println(p.getClass());
		System.out.println(p2.getClass());
	}
}
