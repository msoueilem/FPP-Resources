package lesson7.staticnested;

class AnotherClass {
	public static void main(String[] args){

		MyClass.MyStaticNestedClass cl = 
					new MyClass.MyStaticNestedClass(); //OK
	}
}
