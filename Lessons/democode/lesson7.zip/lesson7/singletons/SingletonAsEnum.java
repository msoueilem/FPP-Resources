package lesson7.singletons;

public enum SingletonAsEnum {
	INSTANCE;
}
