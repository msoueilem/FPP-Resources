package lesson7.singletons;

public class SingletonAsPublicStatic {
	//eager initialization
	public static final SingletonAsPublicStatic INSTANCE 
		= new SingletonAsPublicStatic();
	
	private SingletonAsPublicStatic() {}
	
	public static void main(String[] args) {
		SingletonAsPublicStatic singleton1 = SingletonAsPublicStatic.INSTANCE;
		SingletonAsPublicStatic singleton2 = SingletonAsPublicStatic.INSTANCE;
		System.out.println(singleton1);
		System.out.println(singleton2);
	}
}
