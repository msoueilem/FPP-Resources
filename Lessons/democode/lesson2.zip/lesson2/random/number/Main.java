package lesson2.random.number;

public class Main {

	public static void main(String[] args) {
		//produces a randomly generated int
		int n = RandomNumbers.getRandomInt(); 
		//produces a randomly generated int in the range 3..11, inclusive.
		int m = RandomNumbers.getRandomInt(3,11); 
		System.out.println(n);
		System.out.println(m);
	}
}
