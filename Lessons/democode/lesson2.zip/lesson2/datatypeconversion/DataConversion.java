package lesson2.datatypeconversion;

public class DataConversion {

	public static void main(String[] args) {

		//int -> long, int -> double automatic, no loss of info
		int x = 123456789;
		long y = x;
		double w = x;
		System.out.println(x);
		System.out.println(y);
		System.out.println(w);


		//int -> float, long -> float, long -> double: automatic but may lose info
		int a = 123456789;
		float b = a;		
		System.out.println("=========");
		System.out.println(a);
		System.out.println(b);

		//char -> int - automatic, nothing lost
		char s = 'a';
		int t = s;
		System.out.println("=========");
		System.out.println(s);
		System.out.println(t);

		//compiler error if cast is not done
		byte ax = 10;
		byte bx = 11;
//		byte sum = ax + bx;
//		byte sum2 = (byte)(ax+bx);
	}

}
